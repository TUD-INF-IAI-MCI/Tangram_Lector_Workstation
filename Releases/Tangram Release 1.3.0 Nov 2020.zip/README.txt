## Installation

To install the TANGRAM Workstation you simply have to install the TangramToolbar_LO_5.oxt extension to your LibreOffice. The version of LibreOffice should be not higher than 5.4.X and not lower than 5.0.*. It is recommended to install the DockingWindow_LO.oxt first!

ATTENTION: Works only width x86 (32 bit) versions of LibreOffice!

In your LibreOffice DRAW app, you can start the Tangram Workstation by pressing Ctrl. + Shift + t 

### Braille Font

Tangram is intended to uses Braille fonts compatible and released with tactile embossers for ViewPlus (tiger / emprint / etc. ) [https://viewplus.com/]. It is recommended to install the Braille font "Braille DE Computer ASCII.ttf" delivered with any ViewPlus product (e.g. tiger software suite).

### Hardware / Tactile Displays

Currently, there is a strong connection to the tactile displays released by metec AG Stuttgart, Germany (https://www.metec-ag.de/). Therefore their API software 'MVBD' (https://download.metec-ag.de/MVBD/) is integrated by default. All rights to the MVBD are lain at metec AG. 


##Configuration:

For configuration of the Tangram Workstation got to the directory 

%appdata%\LibreOffice\4\user\uno_packages\cache\uno_packages\[*some strange folder*]\TangramToolbar_LO_5.oxt\TangramLector\

and edit the config file TangramLector.exe.config


## Extensions to Tangram (new hardware or functions)

Install extensions in the same way by simply copying the extension folder to one of the both Extension directories:

%appdata%\LibreOffice\4\user\uno_packages\cache\uno_packages\[*some strange folder*]\TangramToolbar_LO_5.oxt\TangramToolbar_LO_5\TangramLector\EXT\ADPT for new hardware or SSFP for new functions

